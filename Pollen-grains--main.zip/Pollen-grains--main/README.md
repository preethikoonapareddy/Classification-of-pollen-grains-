# Pollen-grains-
This project uses Artificial Intelligence to identify pollen grains from images. It uses a CNN (Convolutional Neural Network) model to classify different types of pollen based on their shape, size, and texture.
